This readme has moved to the parent Notifications folder.
